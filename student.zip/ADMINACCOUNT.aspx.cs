﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class ADMINACCOUNT : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            lbldate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            lblmonth.Text = DateTime.Now.ToString("MM");
            lblyear.Text = DateTime.Now.ToString("yyyy");
        }
        private void pay()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select sum(paymentPayble) from Payment where studentID='"+txtsearch.Text+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txttotalpayble.Text = dt.Rows[0][0].ToString();

        }
        private void rec()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select sum(receivedAmount) from Account where studentID='" + txtsearch.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
           txttotalpaid.Text = dt.Rows[0][0].ToString();
        }

        private void due()
        {
            double paid, pay, due = 0;
            paid = Convert.ToDouble(txttotalpaid.Text);
            pay = Convert.ToDouble(txttotalpayble.Text);
            due = pay - paid;
            lbldue.Text = "Total Due is: " + due.ToString() + " Taka";
        }
        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                  pay();
            rec();
            due();
            }
            catch (Exception)
            {
                
              
            }
      
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                  SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Account values('"+txtnewamount.Text+"','"+lbldate.Text+"','"+lblmonth.Text+"','"+lblyear.Text+"','"+txtsearch.Text+"')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            lblmsg.Text = "Transection Sucessfully";
            con.Close();
            }
            catch (Exception)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid Input');", true);
            }
        }
    }
}