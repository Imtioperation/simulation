﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class admindepartment : System.Web.UI.Page
    {
        /*Connection string */
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            btnupdate.Visible = false;
            btndelete.Visible = false;

        }
        /*This Is  Search button function*/
        protected void btnsearch_Click(object sender, EventArgs e)
        {
            show();
            btnsubmit.Enabled = false;
            btnupdate.Visible = true;
            btndelete.Visible = true;
            txtid.Enabled = false;
       
           
        }
        private void show()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Department where deptID='" + txtsearch.Text + "'", con);
            DataTable ds = new DataTable();
            sda.Fill(ds);
            txtid.Text = ds.Rows[0]["deptID"].ToString();
            txtdepname.Text = ds.Rows[0]["deptName"].ToString();
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Department values('"+txtid.Text+"','"+txtdepname.Text+"')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            lblmsg.Text = "Department Sucessfully Entry";
            con.Close();
          
            }
            catch (Exception)
            {

                lblmsg.Text = "Invalid";
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update Department set deptName='"+txtdepname.Text+"' where deptID='"+txtid.Text+"'";
                    //"insert into Department values('" + txtid.Text + "','" + txtdepname.Text + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();
                lblmsg.Text = "Department Name Update Sucessfully ";
                con.Close();

            }
            catch (Exception)
            {

                lblmsg.Text = "Invalid";
            }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "delete  Department where deptID='"+txtid.Text+"'";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            lblmsg.Text = "Delete Complete";
            con.Close();
        }
    }
}