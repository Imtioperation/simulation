﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class studentamount : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            lbldeptid.Visible = false;
            lblid.Text=Session["user"].ToString();
            lblid.Visible = false;
            try
            {
                Show();
                dept();
                string ide = Session["user"].ToString();
                TotalPayble(ide);
                TotalReceived(ide);
                double pay, rec;
                pay = Convert.ToDouble(lblpayble.Text);
                rec = Convert.ToDouble(lblcollect.Text);
                Totaldue(pay,rec);

            }
            catch (Exception)
            {
                
                
            }
        }
        private void dept()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Department where deptID='"+lbldeptid.Text+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lbldeptname.Text = dt.Rows[0]["deptName"].ToString();
        }
        private void Show()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='"+Session["user"].ToString()+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblname.Text = dt.Rows[0]["firstName"].ToString();
            lbllastname.Text = dt.Rows[0]["lastname"].ToString();
            lbldeptid.Text = dt.Rows[0]["department"].ToString();
            lblbloodgroup.Text = dt.Rows[0]["bloodgroup"].ToString();
            lbldateofbirth.Text = dt.Rows[0]["dateofBirth"].ToString();
            lblphone.Text = dt.Rows[0]["phone"].ToString();
            lbladdmissiondate.Text = dt.Rows[0]["AddmissionDate"].ToString();
        }
        private void TotalPayble( string id)
        {
            SqlDataAdapter sda = new SqlDataAdapter("select sum(paymentPayble) from Payment where studentID='"+id.ToString()+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblpayble.Text = dt.Rows[0][0].ToString();
        }
        private void TotalReceived( string id)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT sum(receivedAmount) FROM Account where studentID='"+id.ToString()+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblcollect.Text = dt.Rows[0][0].ToString();
        }
        private void Totaldue(double pay,double received)
        {
            double due = pay - received;
            lbldue.Text = due.ToString();
            
        }
    }
}