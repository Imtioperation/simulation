﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class studentCourse : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = Session["user"].ToString();
            Label1.Visible = false;
        }

        protected void ddlsemister_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
          
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='" + Session["user"].ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            string name = dt.Rows[0]["firstName"].ToString();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into ActivityLog values('" + DateTime.Now.ToString() + "','Hi " + name.ToString() + " This time you show semister Course List','" + Session["user"].ToString() + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
       
        }
    }
}