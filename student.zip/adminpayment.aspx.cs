﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace StudentPortal
{
    
    public partial class adminpayment : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
           // lbldemo.Visible = false;
            txtcredit.Enabled = false;
            txttotalpayble.Enabled = false;
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
             SqlDataAdapter sda = new SqlDataAdapter("select sum(credit) from Registration  where studentID='"+txtsearch.Text+"' and semister='"+ddlsemister.SelectedItem.ToString()+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txtcredit.Text = dt.Rows[0][0].ToString();
            calculate();
            show();
            demo();
            txtsearch.Enabled = false;
            }
            catch (Exception)
            {
                
                
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid');", true);
            }
        }
        private void show()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Registration  where studentID='" + txtsearch.Text + "' and semister='" + ddlsemister.SelectedItem.ToString() + "'", con);
            DataSet dt = new DataSet();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        private void calculate()
        {
            double cr=Convert.ToDouble(txtcredit.Text), tk=2500, pay=0;
            pay = cr * tk;
            txttotalpayble.Text = pay.ToString();
        }
        private void demo()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select sum(paymentPayble) from Payment where studentID='"+txtsearch.Text+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lbldemo.Text = dt.Rows[0][0].ToString();
        }
      
        protected void btnsubmit_Click(object sender, EventArgs e)
        {

            try
            {
                 SqlDataAdapter sda = new SqlDataAdapter("select count(*) from Payment where semister='"+ddlsemister.SelectedItem.ToString()+"' and studentID='"+txtsearch.Text+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() != "1")
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Payment values('" + txtsearch.Text + "','" + txttotalpayble.Text + "','" + ddlsemister.SelectedItem.ToString() + "')";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();
                lblmsg.Text = "Payment Amount Sucessfully Entry";
                con.Close();
            }
            else
            {
                lblmsg.Text = "This Semister Payment Already Entry";
            }
            }
            catch (Exception)
            {

                lblmsg.Text = "Invalid Input";
            }
                 
           
           
           
        }
    }
}