﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class admindash : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            totalstudent();
            cse();
            swe();
            eee();
            today();
            month();
            year();
        }
        private void totalstudent()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Student", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lbltotalstudent.Text = dt.Rows[0][0].ToString();
        }
        private void cse()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from Student where department='15'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblcse.Text = dt.Rows[0][0].ToString();
        }
        private void swe()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from Student where department='16'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblswe.Text = dt.Rows[0][0].ToString();
        }
        private void eee()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from Student where department='17'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lbleee.Text = dt.Rows[0][0].ToString();
        }
        private void today()
        {
            string day = DateTime.Now.ToString("dd/MM/yyyy");
            SqlDataAdapter sda = new SqlDataAdapter("select sum(receivedAmount) from Account where receiveddate='"+day.ToString()+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lbltodaycollect.Text = dt.Rows[0][0].ToString();
        }
        private void month()
        {
            string month = DateTime.Now.ToString("MM");
            SqlDataAdapter sda = new SqlDataAdapter("select sum(receivedAmount) from Account where receivedmonth='" + month.ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblmonthcollect.Text = dt.Rows[0][0].ToString();
        }
        private void year()
        {
            string year = DateTime.Now.ToString("yyyy");
            SqlDataAdapter sda = new SqlDataAdapter("select sum(receivedAmount) from Account where receivedyear='" + year.ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblyearcollect.Text = dt.Rows[0][0].ToString();
        }
    }
}