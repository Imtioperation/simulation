﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class studentportal : System.Web.UI.MasterPage
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            lblid.Text = Session["user"].ToString();
            name();
        }
        private void name()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='"+Session["user"].ToString()+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblusername.Text = dt.Rows[0]["firstName"].ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("studentamount.aspx");
        
       
        
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("studentprofile.aspx");
          
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("studentlogin.aspx");
         
        }

 

        protected void Button3_Click1(object sender, EventArgs e)
        {
            Response.Redirect("studentCourse.aspx");
        
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("result.aspx");
       
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("activitylog.aspx");
        }
    }
}