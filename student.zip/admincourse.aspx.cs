﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class admincourse : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            btnupdate.Visible = false;
            btndelete.Visible = false;
            allshow();
        }
        private void allshow()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Course order by id desc", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        private void show()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Course order by id desc", con);
            DataTable ds = new DataTable();
            sda.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        /*This function used insert data in database*/
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
             SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Course values('"+txtcoursecode.Text+"','"+txtcoursename.Text+"','"+ddldepartment.SelectedValue+"','"+txtcredit.Text+"')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            lblmsg.Text="This Course Entry Sucessfully";
            con.Close();
            show();
            }
            catch (Exception)
            {

                lblmsg.Text = "Invalid Input";
            }

        }
        /*This function used by show only one rows data data*/
        private void all1()
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from Course where courseCode='" + txtcodesearch.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txtcoursecode.Text = dt.Rows[0]["courseCode"].ToString();
            txtcoursename.Text = dt.Rows[0]["courseName"].ToString();
            ddldepartment.Text = dt.Rows[0]["dept"].ToString();
            txtcredit.Text = dt.Rows[0]["credit"].ToString();
            }
            catch (Exception)
            {

                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Please Some text here');", true);

            }
               
        }
        /*This function used by show all data*/
        private void all2()
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from Course where dept='" + ddldeptsearch.SelectedValue + "'", con);
            DataSet dt = new DataSet();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            }
            catch (Exception)
            {

                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Some text here ');", true);

            }
        }
     
     

        protected void btnsearch_Click(object sender, EventArgs e)
        {
           


            all2();
       
        }
        /*This Is a Search Button Function and Called some method using this method iam search course*/
        protected void btn_Click(object sender, EventArgs e)
        {
            try
            {
                  btnupdate.Visible = true;
            btndelete.Visible = true;
            btnsubmit.Enabled = false;
            txtcoursecode.Enabled = false;
            all1();
            }
            catch (Exception)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Please Some text here');", true);

              
            }
        }
        /*This IS a Update Command and code*/
       protected void btnupdate_Click(object sender, EventArgs e)
       {
           try
           {
               SqlCommand cmd = new SqlCommand();
               cmd.CommandText = "update Course set courseName='" + txtcoursename.Text + "',dept='" + ddldepartment.SelectedValue + "',credit='"+txtcredit.Text+"' where courseCode='" + txtcoursecode.Text + "'";
                   //"insert into Course values('" + txtcoursecode.Text + "','" + txtcoursename.Text + "','" + ddldepartment.SelectedValue + "')";
               cmd.CommandType = CommandType.Text;
               cmd.Connection = con;
               con.Open();
               cmd.ExecuteNonQuery();
               lblmsg.Text = "This Course Update Sucessfully";
               con.Close();
               show();
           }
           catch (Exception)
           {

               lblmsg.Text = "Invalid Input";
           }
       }
       /*This IS a Delete Command and code*/
        protected void btndelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "delete Course where courseCode='"+txtcoursecode.Text+"'";
                //"update Course set courseName='" + txtcoursename.Text + "',dept='" + ddldepartment.SelectedValue + "' where courseCode='" + txtcoursecode.Text + "'";
            //"insert into Course values('" + txtcoursecode.Text + "','" + txtcoursename.Text + "','" + ddldepartment.SelectedValue + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            lblmsg.Text = "This Course Update Sucessfully";
            con.Close();
            show();
        }

       
    }
}