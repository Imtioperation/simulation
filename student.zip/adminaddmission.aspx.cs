﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class adminaddmission : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            lbldate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            lbldate.Visible = false;
            btnupdate.Visible = false;
     
        }
        /*Search Command For Student*/
        protected void btnsearch_Click(object sender, EventArgs e)
        {
            btnupdate.Visible = true;
          
            btnsubmit.Enabled = false;
            txtid.Enabled = false;
         
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='"+txtsearch.Text+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txtid.Text = dt.Rows[0]["studentID"].ToString();
            txtfstname.Text = dt.Rows[0]["firstName"].ToString();
            txtlastname.Text = dt.Rows[0]["lastname"].ToString();
            txtfathername.Text = dt.Rows[0]["fatherName"].ToString();
            txtmothername.Text = dt.Rows[0]["motherName"].ToString();
            txtparentsphone.Text = dt.Rows[0]["parentsPhone"].ToString();
            txtphone.Text = dt.Rows[0]["phone"].ToString();
            txtemail.Text = dt.Rows[0]["email"].ToString();
            txtnationality.Text = dt.Rows[0]["nationalit"].ToString();
            txtdateofbirth.Text = dt.Rows[0]["dateofBirth"].ToString();
            ddldept.Text = dt.Rows[0]["department"].ToString();
            ddlbloodgroup.Text = dt.Rows[0]["bloodgroup"].ToString();
            txtpassword.Text = dt.Rows[0]["portalPassword"].ToString();
        }
        /*Insert Command For Student*/
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                          
            
                 if (ddlbloodgroup.SelectedIndex != 0)
            {
                SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Student where studentID='"+txtid.Text+"' and phone='"+txtphone.Text+"'",con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString() != "1")
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "insert into Student values ('" + txtid.Text + "','" + txtfstname.Text + "','" + txtlastname.Text + "','" + txtpassword.Text + "','" + txtemail.Text + "','" + txtphone.Text + "','" + txtnationality.Text + "','" + txtpresentaddress.Text + "','" + txtparmanenetaddress.Text + "','" + txtfathername.Text + "','" + txtmothername.Text + "','" + txtparentsphone.Text + "','" + ddldept.SelectedValue + "','" + ddlbloodgroup.SelectedItem.ToString() + "','" + txtdateofbirth.Text + "','" + lbldate.Text + "')";
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    lblmsg.Text = "Addmission Successfully Completed";
                    con.Close();
                }
                else
                {
                    lblmsg.Text = "ID or phone already exist";
                }
         
            }
            else
            {
                lblmsg.Text = "Please Select Blood Group";
            }
          
           
            }
            catch (Exception)
            {

                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid Input');", true);
            }
        
        }
        /*Update Command For Student*/
        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                     SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "update Student set firstName='"+txtfstname.Text+"',portalPassword='"+txtpassword.Text+"',lastname='"+txtlastname.Text+"',email='"+txtemail.Text+"',phone='"+txtphone.Text+"',nationalit='"+txtnationality.Text+"',fatherName='"+txtfathername.Text+"',motherName='"+txtmothername.Text+"',parentsPhone='"+txtparentsphone.Text+"',dateofBirth='"+txtdateofbirth.Text+"' where studentID='"+txtid.Text+"'";

                //"insert into Student values ('" + txtid.Text + "','" + txtfstname.Text + "','" + txtlastname.Text + "','" + txtpassword.Text + "','" + txtemail.Text + "','" + txtphone.Text + "','" + txtnationality.Text + "','" + txtpresentaddress.Text + "','" + txtparmanenetaddress.Text + "','" + txtfathername.Text + "','" + txtmothername.Text + "','" + txtparentsphone.Text + "','" + ddldept.SelectedValue + "','" + ddlbloodgroup.SelectedItem.ToString() + "','" + txtdateofbirth.Text + "','" + lbldate.Text + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            lblmsg.Text = "Update Successfully Completed";
            con.Close();
            }
            catch (Exception)
            {
                
                 Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid Input');", true);
             }
        }
    }
}