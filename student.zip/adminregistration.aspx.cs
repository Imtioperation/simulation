﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace StudentPortal
{
    public partial class adminregistration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
          
            txtcoursecode.Enabled = false;
            txtcoursetitle.Enabled = false;
            txtcredit.Enabled = false;
            GridView3.Visible = false;
        }

        protected void btnstudentsearch_Click(object sender, EventArgs e)
        {
           
            btnsubmit.Enabled = false;
            /*SqlDataAdapter sda = new SqlDataAdapter("select courseCode,courseName from Registration where semister='"+ddlsemistersearch.SelectedItem.ToString()+"' and studentID='"+txtidsearch.Text+"'",con);
                //("select courseCode,courseName,credit from Course  where dept='" + ddldeptsearch.SelectedValue + "' order by id desc", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            GridView2.DataSource = ds;
            GridView2.DataBind();*/
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            GridView3.Visible = true;
        }



        private void demo()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Registration where (studentID='"+txtstudentid.Text+"' and courseCode='"+txtcoursecode.Text+"') and semister='"+ddlsemister.SelectedItem.ToString()+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() != "1")
            {
             
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Registration values('" + txtcoursecode.Text + "','" + txtcoursetitle.Text + "','" + txtcredit.Text + "','" + txtstudentid.Text + "','" + ddlsemister.SelectedItem.ToString() + "','" + ddldepartment.SelectedValue + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            lblmsg.Text = "This Course Registerd";
            con.Close();
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('This Course Already Registred for this semister');", true);
            }
        
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            GridView3.Visible = true;
            try
            {

                if (ddlsemister.SelectedIndex != 0)
                {
                    SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Student where studentID='" + txtstudentid.Text + "' and department='"+ddldepartment.SelectedValue+"'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        demo();
                    
                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('This ID not in exist please enter valid student ID');", true);
                    }
                 
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Please Select Valid Semister');", true);
                }
               
            }
            catch (Exception)
            {
                
                
            }
        }

        protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView3.Visible = true;
            GridViewRow gr = GridView3.SelectedRow;
            txtcoursecode.Text = gr.Cells[1].Text;
            txtcoursetitle.Text = gr.Cells[2].Text;
            txtcredit.Text = gr.Cells[3].Text;

        }

      
    }
}