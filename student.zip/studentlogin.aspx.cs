﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class studentlogin : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void invalid()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Student where studentID='" + txtuserid.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() != "1")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid StudentID');", true);
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid Password');", true);
            }
        }
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            Session["user"] = txtuserid.Text;
            Session["password"] = txtpassword.Text;
            try
            {
                Activity();
                  SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Student where studentID='"+txtuserid.Text+"' and portalPassword='"+txtpassword.Text+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                Response.Redirect("studentdash.aspx");
            }
            else
            {
                invalid();
            }
            }
            catch (Exception)
            {
                
               Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid Input');", true);
            }
                
         
        }
        private void Activity()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='" + Session["user"].ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            string name = dt.Rows[0]["firstName"].ToString();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into ActivityLog values('"+DateTime.Now.ToString()+"','Hi "+name.ToString()+" Now you Login student portal','"+Session["user"].ToString()+"')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        protected void btnlog_Click(object sender, EventArgs e)
        {
            if (txtuserid.Text == "123" && txtpassword.Text == "123")
            {
                Response.Redirect("admindash.aspx");
            }
            else
            {
                lblmsg.Text = "Not Allright";
            }
        }

       
    }
}