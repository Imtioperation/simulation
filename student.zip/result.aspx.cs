﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace StudentPortal
{
    public partial class result : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                lbltotal.Visible = false;
                lblcredit.Visible = false;
                lbldptid.Visible = false;
          
            }
            catch (Exception)
            {
                
                
            }
        }
        private void total()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select sum(total) from result where studentID='"+txtstudentid.Text+"' and semister='"+ddlsemister.SelectedItem.ToString()+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lbltotal.Text = dt.Rows[0][0].ToString();

        }
           private void credit()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select sum(credit) from result where studentID='"+txtstudentid.Text+"' and semister='"+ddlsemister.SelectedItem.ToString()+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
           lblcredit.Text = dt.Rows[0][0].ToString();

        }
           private void calculate()
           {
               double total, credit,sgpa=0;
               total = Convert.ToDouble(lbltotal.Text);
               credit = Convert.ToDouble(lblcredit.Text);
               sgpa = total / credit;
               lblsgpa.Text = sgpa.ToString();
           }
        private void dept()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Department where deptID='"+lbldptid.Text+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lbldptname.Text = dt.Rows[0]["deptName"].ToString();
        }
        private void type()
        {
            double sgpa = Convert.ToDouble(lblsgpa.Text);
            if(sgpa>=1.00 && sgpa<=4.00){
                lbltype.Text = "Passed";
            }
            else
            {
                lbltype.Text = "Failed";
            }
        }
        private void Activity()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='" + Session["user"].ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            string name = dt.Rows[0]["firstName"].ToString();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into ActivityLog values('" + DateTime.Now.ToString() + "','Hi " + name.ToString() + " This time you show semister result we hope your result is very good','" + Session["user"].ToString() + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
               
                 Session["sid"]=txtstudentid.Text;
           Session["semister"] = ddlsemister.Text;
           SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='"+txtstudentid.Text+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblfstname.Text = dt.Rows[0]["firstName"].ToString();
            lbllastname.Text = dt.Rows[0]["lastname"].ToString();
            lblstudentid.Text = Session["sid"].ToString();
            lblsemister.Text = Session["semister"].ToString();
                lbldptid.Text = dt.Rows[0]["department"].ToString();
                dept();
                total();
                credit();
                calculate();
                type();
                Activity();

            }
            catch (Exception)
            {
                
                
            }

        }

        
    }
}