﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace StudentPortal
{
    public partial class adminresult : System.Web.UI.Page
    {
        string query;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView1.SelectedRow;
            txtcoursecode.Text=gr.Cells[1].Text;
            txtcoursename.Text = gr.Cells[2].Text;
            txtcredit.Text = gr.Cells[3].Text;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            txtidsearch.Enabled = false;
            ddlsemister.Enabled = false;
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            query = "select count(*) from result where (studentID='"+txtidsearch.Text+"' and semister='"+ddlsemister.SelectedItem.ToString()+"') and courseCode='"+txtcoursecode.Text+"'";
            if (ddlgrade.SelectedIndex != 0)
            {
                try
                {
                    SqlDataAdapter sda = new SqlDataAdapter(query,con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() != "1")
                    {
                        SqlCommand cmd = new SqlCommand();
                        cmd.CommandText = "insert into result values('" + txtidsearch.Text + "','" + ddlsemister.SelectedItem.ToString() + "','" + txtcoursecode.Text + "','" + txtcoursename.Text + "','" + txtpoint.Text + "','" + ddlgrade.SelectedItem.ToString() + "','"+txtcredit.Text+"')";
                        cmd.CommandType = CommandType.Text;
                        cmd.Connection = con;
                        con.Open();
                        cmd.ExecuteNonQuery();
                        lblmsg.Text = "Result Entry Sucessfully";
                        con.Close();
                    }
                    else
                    {
                        lblmsg.Text = "This Course Result For this semister already entry";
                    }
               
                }
                catch (Exception)
                {

                    lblmsg.Text = "Invalid Input";
                }
            }
            else
            {
                lblmsg.Text = "Please Select Valid Semister";
            }
        }
    }
}