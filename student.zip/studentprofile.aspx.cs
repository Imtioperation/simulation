﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace StudentPortal
{
    public partial class studentprofile : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            
            lbldpt.Visible = false;
            try
            {
              update();
            department();
            }
            catch (Exception)
            {
                
                
            }

        }
        private void department()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Department where deptID='"+lbldpt.Text+"'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txtdept.Text = dt.Rows[0]["deptName"].ToString();
        }
        private void update()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='"+Session["user"].ToString()+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txtfstname.Text=dt.Rows[0]["firstName"].ToString();
            txtlstname.Text = dt.Rows[0]["lastname"].ToString();
            txtfathername.Text = dt.Rows[0]["fatherName"].ToString();
            txtmothername.Text = dt.Rows[0]["motherName"].ToString();
            txtphone.Text = dt.Rows[0]["phone"].ToString();
            txtemail.Text = dt.Rows[0]["email"].ToString();
            txtparentsphone.Text = dt.Rows[0]["parentsPhone"].ToString();
            txtpassword.Text = dt.Rows[0]["portalPassword"].ToString();
            txtparmanenet.Text = dt.Rows[0]["parmanentAddress"].ToString();
            txtpresentaddress.Text = dt.Rows[0]["presentAddress"].ToString();
            lbldpt.Text = dt.Rows[0]["department"].ToString();
            txtnationality.Text = dt.Rows[0]["nationalit"].ToString();
            ddlbloodgroup.Text = dt.Rows[0]["bloodgroup"].ToString();
            txtdateofbirth.Text = dt.Rows[0]["dateofBirth"].ToString();
            txtaddmissiondate.Text = dt.Rows[0]["AddmissionDate"].ToString();
        }
        private void Activity()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Student where studentID='" + Session["user"].ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            string name = dt.Rows[0]["firstName"].ToString();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into ActivityLog values('" + DateTime.Now.ToString() + "','Hi " + name.ToString() + " This time you Update your personal profile','" + Session["user"].ToString() + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {

            try
            {

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update Student set portalPassword='" + txtpassword.Text + "',nationalit='" + txtnationality.Text + "',presentAddress='" + txtpresentaddress.Text + "',parmanentAddress='" + txtparmanenet.Text + "',bloodgroup='" + ddlbloodgroup.SelectedItem.ToString() + "' where studentID='" + Session["user"].ToString() + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Profile Successfully Update');", true);
                con.Close();
                Activity();



            }
            catch (Exception)
            {

                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Invalid Input');", true);
            }
        }


        
    }
}